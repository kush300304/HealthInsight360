from azure.storage.blob import BlobServiceClient
import os
import pandas as pd
import schedule
import time

# Define your Azure Blob Storage connection string
connection_string = "DefaultEndpointsProtocol=https;AccountName=minorwork12;AccountKey=0AC1UyNrHhgzxDACS3KlbJb9vDzaCKtEyAe4bW3ISxs5C0Z+RyVSv4qqhnfKkSVgW3ll7u3oZdi8+AStNJ1hoQ==;EndpointSuffix=core.windows.net"

# Define the Blob Storage container name
container_name = "healthinsight"

# Define the directory where you want to save the CSV files locally
local_csv_directory = r"C:\Users\kusha\Desktop\healthinsight\Connect_Cloud\files"

# Create a BlobServiceClient object
blob_service_client = BlobServiceClient.from_connection_string(connection_string)

# Get a reference to the container
container_client = blob_service_client.get_container_client(container_name)

# Function to convert txt to csv
def convert_txt_to_csv(blob_name, content, csv_directory):
    # Create a DataFrame from the content
    df = pd.DataFrame([line.strip().split(',') for line in content.split('\n')])
    # Define the csv filename
    csv_filename = os.path.splitext(blob_name)[0] + ".csv"
    # Save the DataFrame as csv
    df.to_csv(os.path.join(csv_directory, csv_filename), index=False, header=False)

# Function to check for updates and update local CSV files
def update_local_csv_files():
    # List all blobs/files in the container
    blob_list = container_client.list_blobs()
    
    # Iterate through each blob in the container
    for blob in blob_list:
        blob_name = blob.name
        if blob_name.endswith(".txt"):
            # Download the blob content
            blob_client = container_client.get_blob_client(blob_name)
            blob_content = blob_client.download_blob().readall().decode('utf-8')
            # Convert txt to csv
            convert_txt_to_csv(blob_name, blob_content, local_csv_directory)

# Schedule the update task to run every 5 minutes
schedule.every(30).seconds.do(update_local_csv_files)

# Run the scheduler loop
while True:
    schedule.run_pending()
    time.sleep(1)