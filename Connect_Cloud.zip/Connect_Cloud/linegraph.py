import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import time

def strip_double_quotes(s):
    """Function to strip double quotes from a string"""
    if isinstance(s, str):
        return s.strip('"')
    else:
        return s

def update_plot_and_save():
    """Function to update plot and save as image"""
    try:
        # Read CSV file 'patients.csv'
        df = pd.read_csv("files/`patients`.csv")

        # Print first few rows to check if data is loaded correctly
        print(df.head())

        # Strip double quotes from the 'BIRTHDATE' column
        df['BIRTHDATE'] = df['BIRTHDATE'].apply(strip_double_quotes)

        # Convert 'BIRTHDATE' strings to datetime objects
        df['BIRTHDATE'] = pd.to_datetime(df['BIRTHDATE'], format='%Y-%m-%d')

        # Calculate age for each patient
        now = pd.Timestamp('now')
        df['AGE'] = (now - df['BIRTHDATE']).dt.days / 365.25  # Divide by number of days in a year

        # Plot age distribution by gender
        plt.clf()  # Clear existing plot
        plt.hist(df[df['GENDER'] == 'male']['AGE'], bins=20, color='blue', alpha=0.7, label='Male')
        plt.hist(df[df['GENDER'] == 'female']['AGE'], bins=20, color='pink', alpha=0.7, label='Female')
        plt.xlabel('Age')
        plt.ylabel('Frequency')
        plt.title('Age Distribution by Gender')
        plt.legend()
        plt.grid(True)
        
        # Print some information to verify if the plot is being generated
        print("Plotting histogram...")
        
        # Save plot as image
        plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\age_distribution_by_gender.png")  # Save image in 'static' directory

    except Exception as e:
        print("Error:", e)

# Initial plot and save
update_plot_and_save()

# Check for changes in CSV file every minute and update the plot
while True:
    try:
        time.sleep(30)  # Check every minute
        update_plot_and_save()
    except KeyboardInterrupt:
        break