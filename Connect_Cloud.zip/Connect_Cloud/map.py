import pandas as pd
import folium
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
# import numpy as np

# Function to strip extra inverted commas from a string
def strip_extra_quotes(s):
    if isinstance(s, str):
        return s.strip('"')
    else:
        return s

# Function to update the map
def update_map(event=None):
    try:
        # Read the CSV files
        patients_df = pd.read_csv("files/`patients`.csv")
        organizations_df = pd.read_csv("files/`organizations`.csv")

        # Strip extra quotes from latitude and longitude columns in patients data
        patients_df['LAT'] = patients_df['LAT'].apply(strip_extra_quotes)
        patients_df['LON'] = patients_df['LON'].apply(strip_extra_quotes)

        # Drop rows with NaN values in patients data
        patients_df = patients_df.dropna(subset=['LAT', 'LON'])
        organizations_df = organizations_df.dropna(subset=['LAT', 'LON'])

        # Convert latitude and longitude to float in patients data
        patients_df['LAT'] = patients_df['LAT'].astype(float)
        patients_df['LON'] = patients_df['LON'].astype(float)

        # Create a map centered at the mean latitude and longitude of patients
        map = folium.Map(location=[patients_df['LAT'].mean(), patients_df['LON'].mean()], zoom_start=4)

        # Add markers for each patient location
        for index, row in patients_df.iterrows():
            folium.Marker([row['LAT'], row['LON']], popup=row['FIRST'], icon=folium.Icon(color='blue')).add_to(map)

        # Add markers for each organization location
        for index, row in organizations_df.iterrows():
            folium.Marker([row['LAT'], row['LON']], popup=row['NAME'], icon=folium.Icon(color='green')).add_to(map)

        # Save the map as an HTML file
        map.save(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\geographical_map.html")

    except Exception as e:
        print("Error:", e)

# Watchdog event handler class
class MyHandler(FileSystemEventHandler):
    def on_modified(self, event):
        update_map(event)

# Initial update
update_map()

# Create a watchdog observer
event_handler = MyHandler()
observer = Observer()
observer.schedule(event_handler, path='.', recursive=False)
observer.start()

try:
    while True:
        time.sleep(60)  # Check every minute
        update_map()  # Update the map
except KeyboardInterrupt:
    observer.stop()

observer.join()