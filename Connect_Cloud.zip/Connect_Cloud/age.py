import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import time

# Function to strip double quotes from a string
def strip_double_quotes(s):
    if isinstance(s, str):
        return s.strip('"')
    else:
        return s

# Function to update plot and save as image
def update_plot_and_save():
    try:
        # Read CSV file 'patients.csv'
        df = pd.read_csv("files/`patients`.csv")

        # Strip double quotes from the 'BIRTHDATE' column
        df['BIRTHDATE'] = df['BIRTHDATE'].apply(strip_double_quotes)

        # Convert 'BIRTHDATE' strings to datetime objects
        df['BIRTHDATE'] = pd.to_datetime(df['BIRTHDATE'], format='%Y-%m-%d')

        # Calculate age for each patient
        now = pd.Timestamp('now')
        df['AGE'] = (now - df['BIRTHDATE']).dt.days / 365.25  # Divide by number of days in a year

        # Plot age distribution
        plt.clf()  # Clear existing plot
        plt.hist(df['AGE'], bins=20, color='skyblue', edgecolor='black')
        plt.xlabel('Age')
        plt.ylabel('Frequency')
        plt.title('Age Distribution of Patients')
        plt.grid(True)

        # Save plot as image
        plt.savefig(r"C:\Users\kusha\Desktop\healthinsight\minorproject\static\img\age_distribution.png")  # Save image in 'static' directory

    except Exception as e:
        print("Error:", e)

# Initial plot and save
update_plot_and_save()

# Check for changes in CSV file every minute and update the plot
while True:
    try:
        time.sleep(30)  # Check every minute
        update_plot_and_save()
    except KeyboardInterrupt:
        break